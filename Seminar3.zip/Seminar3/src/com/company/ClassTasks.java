package com.company;

public class ClassTasks {
    public static void main(String[] args) {
        Point p = new Point(34, 56);
        Circle c = new Circle(46, 34, 7);
        Square s = new Square(46, 34, 8);
        p.Display();
        c.Display();
        s.Display();
    }
}
